# Cure ERP — Frontend (Phase: Module UI with modal-window forms)

React + TypeScript + Vite + MUI + react-hook-form + zod + TanStack Query.

## Run it

```bash
npm install
npm run dev
```
Opens at http://localhost:5173. Data is stored in `localStorage` via `src/lib/api/mockApi.ts` — no backend needed yet.

## What's here

Two fully wired modules, built to be the template for every other module in the architecture spec:

- **Item Master** (`src/modules/masters/items`) — simple master CRUD.
- **Purchase Order — Domestic** (`src/modules/purchase/orders-domestic`) — header form + dynamic line-items subform with live Gross/Taxable Value/CGST/IGST calculation and a Net Total.

## The modal-window form pattern

Every module opens its create/edit form inside the same **`<FormModal>`** component (`src/components/FormModal.tsx`) instead of navigating to a separate page:

```
ListPage (DataTable)
   └─ "New" button / row click → opens <FormModal>
        └─ <XyzForm ref={formRef} .../>   ← react-hook-form + zod, imperative submit()
   FormModal's Save button calls formRef.current.submit()
   On valid submit → useCrud().create()/update() → modal closes, table refreshes
```

To add a new module (e.g. GRN, Imprest Out):
1. Add the type to `src/types/index.ts` (field names should match the DB columns in `Cure-ERP-Architecture-Spec.md` §3).
2. Add a zod schema in `src/lib/validation/`.
3. Build `<XyzForm>` following `ItemForm.tsx` (simple) or `PurchaseOrderForm.tsx` (header + line-items subform) as the template.
4. Build `<XyzPage>` following `ItemsPage.tsx` / `PurchaseOrdersPage.tsx` — DataTable + FormModal + `useCrud<Xyz>("resourceName")`.
5. Register the resource name in `mockApi.ts`'s `Resource` union and `Db` interface, and add the route in `App.tsx` + nav entry in `AppShell.tsx`.

## Swapping the mock API for the real backend

Every module calls `useCrud<T>(resource)` (`src/lib/api/useCrud.ts`), which calls the four functions in `mockApi.ts` (`list/create/update/remove`). Once the Express/Prisma backend (Phase 1 of the dev plan) exists, replace the bodies of those four functions with `fetch("/api/v1/...")` calls matching the endpoints in the architecture spec §5 — no component code changes required.

## Known placeholders (see architecture spec §12 for the full list)

- Vendor list in the PO form is hardcoded (`VENDORS` const) pending the Vendor Master module.
- CGST/IGST use a flat 6%/12% placeholder rate, not the real HSN-based tax table.
- Approval-matrix routing, document-number sequencing, and RBAC are not yet wired — this phase is UI + client-side workflow shape only.
